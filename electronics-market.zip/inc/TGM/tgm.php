<?php
	
load_template( get_template_directory() . '/inc/TGM/class-tgm-plugin-activation.php' );

/**
 * Recommended plugins.
 */
function electronics_market_register_recommended_plugins() {
	$plugins = array(
		array(
			'name'             => __( 'WooCommerce', 'electronics-market' ),
			'slug'             => 'woocommerce',
			'required'         => false,
			'force_activation' => false,
		),
		array(
            'name'             => __( 'GTranslate', 'electronics-market' ),
            'slug'             => 'gtranslate',
            'required'         => false,
            'force_activation' => false,
        ),
        array(
			'name'             => __( 'Ovation Elements', 'electronics-market' ),
			'slug'             => 'ovation-elements',
			'required'         => false,
			'force_activation' => false,
		)
	);
	$config = array();
	electronics_market_tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'electronics_market_register_recommended_plugins' );