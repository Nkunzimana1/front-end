﻿=== Electronics Market ===

Contributors: pewilliams
Requires at least: 6.1
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html
Tags: e-commerce, portfolio, blog, one-column, two-columns, custom-colors, custom-menu, custom-logo, sticky-post, threaded-comments, right-sidebar, left-sidebar, grid-layout, custom-background, rtl-language-support, featured-images, wide-blocks, editor-style, full-site-editing, block-patterns, block-styles, style-variations, template-editing, translation-ready

== Description ==

The Electronics Market WordPress Theme is a robust and versatile theme designed specifically for electronics retailers and online stores. Ideal for selling a wide range of products, from mobile electronics and home appliances to DIY kits and IoT devices, this theme helps create a dynamic, professional online presence. Whether you're selling consumer electronics, electronic components, or offering electronics repair services, this theme provides all the tools needed to build an engaging and user-friendly store. Packed with eCommerce features, such as customizable product pages, secure payment gateways, and an intuitive shopping cart, this theme makes it easy for customers to browse and purchase their favorite electronic gadgets. The clean and modern design ensures that your store looks professional and easy to navigate, while responsive design ensures a seamless shopping experience across devices. With options for product categories like smart electronics, wearables, and gaming accessories, as well as powerful SEO optimization, this theme is perfect for showcasing the latest gadgets, upcoming tech, or even offering special deals. The theme also supports product reviews, discounts, and promotions, which can help boost customer engagement and increase sales. Its user-friendly interface, customizable layouts, and advanced features like product search filters and secure checkout make it a top choice for electronics retailers looking to grow their online business and enhance the customer experience.

== Theme Resources ==

Theme is built using the following resource bundles:
		
1) Details of images used in Screenshot:
        
Image for Banner, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/50830

Image for Banner, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/1595187

Image for Banner, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/682808

Image for Banner, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/1620814

Image for Section, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/1451379

Image for Section, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/673329

Image for Section, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/1091005

Image for Section, copyrights under Creative Commons CC0
License: CC0 1.0 Universal (CC0 1.0)
LICENSE URL: https://pxhere.com/en/license
SOURCE URL: https://pxhere.com/en/photo/1595199 

* Fonts: Barlow Condensed
Copyright (c) Jeremy Tribby
License: These fonts are licensed under the Open Font License.
LICENSE URL: https://fonts.google.com/specimen/Barlow+Condensed/license
SOURCE URL: https://fonts.google.com/specimen/Barlow+Condensed

* Fonts: Oswald
Copyright (c) Vernon Adams, Kalapi Gajjar, Cyreal 
License: These fonts are licensed under the Open Font License.
LICENSE URL: https://fonts.google.com/specimen/Oswald/license
SOURCE URL: https://fonts.google.com/specimen/Oswald

* WOW JS
Copyright 2016, Matthieu Aussaguel
LICENSE URL: GPLv3 https://github.com/matthieua/WOW/blob/master/README.md
SOURCE URL: https://github.com/matthieua/WOW

* Animate CSS
Copyright 2021, Daniel Eden
LICENSE URL: 2.1 https://github.com/animate-css/animate.css/blob/main/LICENSE
SOURCE URL: https://github.com/animate-css/animate.css

* Font Awesome Free 6.7.0
Copyright, fontawesome
License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
https://fontawesome.com

* TGMPA
GaryJones Copyright (C) 1989, 1991
License: GNU General Public License v2.0
LICENSE URL https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md
SOURCE URL: https://github.com/TGMPA/TGM-Plugin-Activation

* Swiper
LICENSE URL: https://app.unpkg.com/swiper@11.1.4/files/LICENSE
SOURCE URL: https://app.unpkg.com/swiper@11.1.4/files/swiper-bundle.js
SOURCE URL: https://app.unpkg.com/swiper@11.1.4/files/swiper-bundle.css

* License
Electronics Market WordPress Theme, Copyright 2025 pewilliams
Electronics Market is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release.

= 1.1 =
* Added style variations.
* Added customizer.
* Added footer link.
* Added scroll top.
* Added fonts.
* Added homepage sections.
* Added slider.

= 1.2 =
* Added heading for index, cart, checkout and single product page.
* Added css for view cart button in shop and single product page.
* Added css for search page and single post on responsive media.
* Resolved css for search button.
* Added hover css for sidebar and scroll to top.