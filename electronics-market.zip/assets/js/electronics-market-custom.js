jQuery(document).ready(function($) {
    $(".head-cat-block select option").each(function() {
        if ($(this).text().trim() === "Select a category") {
            $(this).text("All Departments");
        }
    });
});