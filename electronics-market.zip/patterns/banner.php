<?php
/**
 * Title: Banner
 * Slug: electronics-market/banner
 * Categories: electronics-market, banner
 */

$electronics_market_swiper_url = trailingslashit(get_template_directory_uri());
$electronics_market_swiper_image = $electronics_market_swiper_url . 'images/banner.png';

$electronics_market_image_url = trailingslashit(get_template_directory_uri());
$electronics_market_image = array(
    $electronics_market_image_url . 'images/banner2.png',
    $electronics_market_image_url . 'images/banner3.png',
    $electronics_market_image_url . 'images/banner4.png',
);
?>

<!-- wp:group {"className":"electronics-market-swiper alignfull","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group electronics-market-swiper alignfull" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"electronics-market-swiper-holder swiper-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"100%"}} -->
<div class="wp-block-group electronics-market-swiper-holder swiper-wrapper" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:cover {"url":"<?php echo esc_url($electronics_market_swiper_image) ?>","id":13,"dimRatio":0,"overlayColor":"heading","isUserOverlayColor":true,"minHeight":500,"minHeightUnit":"px","sizeSlug":"large","align":"wide","className":"banner-image-cover swiper-slide","style":{"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-cover alignwide banner-image-cover swiper-slide" style="padding-right:0;padding-left:0;min-height:500px"><img class="wp-block-cover__image-background wp-image-13 size-large" alt="" src="<?php echo esc_url($electronics_market_swiper_image) ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-heading-background-color has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:columns {"className":"banner-content-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns banner-content-wrapper" style="margin-top:0;margin-bottom:0"><!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-content wow flipInX"} -->
<div class="wp-block-column is-vertically-aligned-center banner-content wow flipInX" style="flex-basis:50%"><!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"50px","lineHeight":"1.2","textTransform":"capitalize"},"spacing":{"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:50px;font-style:normal;font-weight:900;line-height:1.2;text-transform:capitalize"><?php esc_html_e('end season smartheadphones','electronics-market'); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"banner-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"textTransform":"capitalize","fontSize":"20px"},"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"textColor":"white"} -->
<p class="banner-text has-white-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50);font-size:20px;text-transform:capitalize"><?php esc_html_e('last call for up to ','electronics-market'); ?><span><?php esc_html_e('$250 OFF!','electronics-market'); ?></span></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"banner-btn","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons banner-btn" style="margin-top:0;margin-bottom:0"><!-- wp:button {"style":{"border":{"radius":"30px"},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"500","textTransform":"capitalize"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-font-size wp-element-button" href="#" style="border-radius:30px;font-size:14px;font-style:normal;font-weight:500;text-transform:capitalize"><?php esc_html_e('start buying','electronics-market'); ?><i class="fas fa-circle-arrow-right"></i></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:spacer {"height":"0px","className":"banner-spacer"} -->
<div style="height:0px" aria-hidden="true" class="wp-block-spacer banner-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-img-box"} -->
<div class="wp-block-column is-vertically-aligned-center banner-img-box" style="flex-basis:50%"><!-- wp:image {"id":15,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url($electronics_market_image[0]) ?>" alt="" class="wp-image-15"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->

<!-- wp:cover {"url":"<?php echo esc_url($electronics_market_swiper_image) ?>","id":13,"dimRatio":0,"overlayColor":"heading","isUserOverlayColor":true,"minHeight":500,"minHeightUnit":"px","sizeSlug":"large","align":"wide","className":"banner-image-cover swiper-slide","style":{"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-cover alignwide banner-image-cover swiper-slide" style="padding-right:0;padding-left:0;min-height:500px"><img class="wp-block-cover__image-background wp-image-13 size-large" alt="" src="<?php echo esc_url($electronics_market_swiper_image) ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-heading-background-color has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:columns {"className":"banner-content-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns banner-content-wrapper" style="margin-top:0;margin-bottom:0"><!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-content wow flipInX"} -->
<div class="wp-block-column is-vertically-aligned-center banner-content wow flipInX" style="flex-basis:50%"><!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"50px","lineHeight":"1.2","textTransform":"capitalize"},"spacing":{"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:50px;font-style:normal;font-weight:900;line-height:1.2;text-transform:capitalize"><?php esc_html_e('end season smartphones','electronics-market'); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"banner-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"textTransform":"capitalize","fontSize":"20px"},"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"textColor":"white"} -->
<p class="banner-text has-white-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50);font-size:20px;text-transform:capitalize"><?php esc_html_e('last call for up to ','electronics-market'); ?><span><?php esc_html_e('$250 OFF!','electronics-market'); ?></span></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"banner-btn","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons banner-btn" style="margin-top:0;margin-bottom:0"><!-- wp:button {"style":{"border":{"radius":"30px"},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"500","textTransform":"capitalize"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-font-size wp-element-button" href="#" style="border-radius:30px;font-size:14px;font-style:normal;font-weight:500;text-transform:capitalize"><?php esc_html_e('start buying','electronics-market'); ?><i class="fas fa-circle-arrow-right"></i></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:spacer {"height":"0px","className":"banner-spacer"} -->
<div style="height:0px" aria-hidden="true" class="wp-block-spacer banner-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-img-box"} -->
<div class="wp-block-column is-vertically-aligned-center banner-img-box" style="flex-basis:50%"><!-- wp:image {"id":15,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url($electronics_market_image[1]) ?>" alt="" class="wp-image-15"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->

<!-- wp:cover {"url":"<?php echo esc_url($electronics_market_swiper_image) ?>","id":13,"dimRatio":0,"overlayColor":"heading","isUserOverlayColor":true,"minHeight":500,"minHeightUnit":"px","sizeSlug":"large","align":"wide","className":"banner-image-cover swiper-slide","style":{"spacing":{"padding":{"right":"0","left":"0"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-cover alignwide banner-image-cover swiper-slide" style="padding-right:0;padding-left:0;min-height:500px"><img class="wp-block-cover__image-background wp-image-13 size-large" alt="" src="<?php echo esc_url($electronics_market_swiper_image) ?>" data-object-fit="cover"/><span aria-hidden="true" class="wp-block-cover__background has-heading-background-color has-background-dim-0 has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:columns {"className":"banner-content-wrapper","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns banner-content-wrapper" style="margin-top:0;margin-bottom:0"><!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-content wow flipInX"} -->
<div class="wp-block-column is-vertically-aligned-center banner-content wow flipInX" style="flex-basis:50%"><!-- wp:heading {"level":1,"style":{"typography":{"fontStyle":"normal","fontWeight":"900","fontSize":"50px","lineHeight":"1.2","textTransform":"capitalize"},"spacing":{"margin":{"top":"0","bottom":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:50px;font-style:normal;font-weight:900;line-height:1.2;text-transform:capitalize"><?php esc_html_e('end season smartheadphones','electronics-market'); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"banner-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"textTransform":"capitalize","fontSize":"20px"},"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}},"textColor":"white"} -->
<p class="banner-text has-white-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50);font-size:20px;text-transform:capitalize"><?php esc_html_e('last call for up to ','electronics-market'); ?><span><?php esc_html_e('$250 OFF!','electronics-market'); ?></span></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"banner-btn","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"flex","justifyContent":"left"}} -->
<div class="wp-block-buttons banner-btn" style="margin-top:0;margin-bottom:0"><!-- wp:button {"style":{"border":{"radius":"30px"},"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"500","textTransform":"capitalize"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-custom-font-size wp-element-button" href="#" style="border-radius:30px;font-size:14px;font-style:normal;font-weight:500;text-transform:capitalize"><?php esc_html_e('start buying','electronics-market'); ?><i class="fas fa-circle-arrow-right"></i></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:spacer {"height":"0px","className":"banner-spacer"} -->
<div style="height:0px" aria-hidden="true" class="wp-block-spacer banner-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%","className":"banner-img-box"} -->
<div class="wp-block-column is-vertically-aligned-center banner-img-box" style="flex-basis:50%"><!-- wp:image {"id":15,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url($electronics_market_image[2]) ?>" alt="" class="wp-image-15"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"electronics-market-swiper-controls","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group electronics-market-swiper-controls" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:html -->
<div class="electronics-market-swiper-button-prev swiper-button-prev"></div>
        <div class="electronics-market-swiper-button-next swiper-button-next"></div>
        <div class="electronics-market-pagination"></div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->