<?php
/**
 * Title: Footer
 * Slug: electronics-market/footer
 * Categories: electronics-market, footer
 */
?>

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"black","layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group has-black-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"className":"footer-widgets","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns footer-widgets"><!-- wp:column {"width":"20%","className":"footer-box-1"} -->
<div class="wp-block-column footer-box-1" style="flex-basis:20%"><!-- wp:group {"className":"logo-row","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group logo-row"><!-- wp:site-logo /-->

<!-- wp:site-title {"style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"28px"}},"textColor":"primary"} /--></div>
<!-- /wp:group -->

<!-- wp:social-links {"iconColor":"white","iconColorValue":"#ffffff","size":"has-normal-icon-size","className":"is-style-logos-only","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|40"}}}} -->
<ul class="wp-block-social-links has-normal-icon-size has-icon-color is-style-logos-only"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"google"} /-->

<!-- wp:social-link {"url":"#","service":"github"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"30%","className":"footer-box-2","style":{"elements":{"link":{"color":{"text":"#ffffff73"}}},"color":{"text":"#ffffff73"}}} -->
<div class="wp-block-column is-vertically-aligned-top footer-box-2 has-text-color has-link-color" style="color:#ffffff73;flex-basis:30%"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:600"><?php esc_html_e('Find it Fast', 'electronics-market'); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"14px"}},"textColor":"white"} -->
<ul style="font-size:14px" class="wp-block-list has-white-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Laptops &amp; Computers','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Cameras &amp; Photography','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Smart Phones &amp; Tablets','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Video Games &amp; Consoles','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('TV &amp; Audio','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Gadgets','electronics-market'); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"14px"}},"textColor":"white"} -->
<ul style="font-size:14px" class="wp-block-list has-white-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Car Electronic &amp; GPS','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Printers &amp; Ink','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Software','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Office Supplies','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Computer Components','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Accesories','electronics-market'); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"30%","className":"footer-box-3","style":{"elements":{"link":{"color":{"text":"#ffffff73"}}},"color":{"text":"#ffffff73"}}} -->
<div class="wp-block-column is-vertically-aligned-top footer-box-3 has-text-color has-link-color" style="color:#ffffff73;flex-basis:30%"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:600"><?php esc_html_e('Customer Care', 'electronics-market'); ?></h2>
<!-- /wp:heading -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"14px"}},"textColor":"white"} -->
<ul style="font-size:14px" class="wp-block-list has-white-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('My Account','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Order Tracking','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Wish List','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Customer Service','electronics-market'); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:list {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"14px"}},"textColor":"white"} -->
<ul style="font-size:14px" class="wp-block-list has-white-color has-text-color has-link-color"><!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Returns / Exchange','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('FAQs','electronics-market'); ?></a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#"><?php esc_html_e('Product Support','electronics-market'); ?></a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"20%","className":"footer-box-4"} -->
<div class="wp-block-column footer-box-4" style="flex-basis:20%"><!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:600"><?php esc_html_e('Contact info', 'electronics-market'); ?></h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"footer-info","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group footer-info"><!-- wp:image {"id":107,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/location.png'); ?>" alt="" class="wp-image-107"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color" style="font-size:14px"><?php esc_html_e('17 Princess Road, London, Greater', 'electronics-market'); ?><br><?php esc_html_e('London NW1 8JR, UK', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"footer-info","style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group footer-info"><!-- wp:image {"id":110,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/call.png'); ?>" alt="" class="wp-image-110"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color" style="font-size:14px"><?php esc_html_e('Got questions? Call us 24/7!', 'electronics-market'); ?><br><?php esc_html_e('(800) 8001-8588,', 'electronics-market'); ?><br><?php esc_html_e('(0600) 874 548', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","left":"0","bottom":"var:preset|spacing|50"}},"border":{"top":{"color":"#99999954","width":"1px"},"right":[],"bottom":[],"left":[]}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide" style="border-top-color:#99999954;border-top-width:1px;padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:0"><!-- wp:group {"className":"copyright-text","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group copyright-text"><!-- wp:paragraph {"className":"has-white-color has-text-color has-link-color","style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"15px"}},"textColor":"white"} -->
<p class="has-white-color has-text-color has-link-color" style="font-size:15px"><a rel="noreferrer noopener" href="https://www.ovationthemes.com/products/electronics-market" target="_blank"><?php esc_html_e('Electronics Market WordPress Theme','electronics-market'); ?></a><?php esc_html_e('Proudly powered by ','electronics-market'); ?><a rel="noreferrer noopener" href="https://www.ovationthemes.com/" target="_blank"><?php esc_html_e('Ovation Themes','electronics-market'); ?></a> <?php esc_html_e('and','electronics-market'); ?> <a href="https://wordpress.org"><?php esc_html_e('WordPress','electronics-market'); ?></a>.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"id":114,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/payment.png'); ?>" alt="" class="wp-image-114"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"className":"scroll-top"} -->
<p class="scroll-top"></p>
<!-- /wp:paragraph -->