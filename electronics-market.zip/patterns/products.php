<?php
/**
 * Title: Products
 * Slug: electronics-market/products
 * Categories: electronics-market, products
 */
?>

<?php if (class_exists('WooCommerce')) { ?>
	<!-- wp:group {"className":"product-sec","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
	<div class="wp-block-group product-sec" style="padding-top:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:group {"className":"sec-head-box","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group sec-head-box"><!-- wp:heading {"style":{"typography":{"fontStyle":"normal","fontWeight":"600","fontSize":"35px"}}} -->
	<h2 class="wp-block-heading" style="font-size:35px;font-style:normal;font-weight:600"><?php esc_html_e('Smarts Phone &amp; Tablets', 'electronics-market'); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:buttons {"className":"section-btns","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons section-btns"><!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Music', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Headphones', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Mobile', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Laptop', 'electronics-market'); ?></a></div>
	<!-- /wp:button --></div>
	<!-- /wp:buttons --></div>
	<!-- /wp:group -->

	<!-- wp:columns {"className":"product-sec-cols"} -->
	<div class="wp-block-columns product-sec-cols"><!-- wp:column {"width":"22.67%","className":"product-box-1"} -->
	<div class="wp-block-column product-box-1" style="flex-basis:22.67%"><!-- wp:woocommerce/product-collection {"queryId":15,"query":{"perPage":1,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"post__in","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false,"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":2,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/hand-picked","hideControls":["inherit","hand-picked","filterable","order"],"queryContextIncludes":["collection"],"__privatePreviewState":{"isPreview":false,"previewMessage":"Actual products will vary depending on the page being viewed."}} -->
	<div class="wp-block-woocommerce-product-collection"><!-- wp:woocommerce/product-template -->
	<!-- wp:group {"className":"product-inner-box","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}},"border":{"radius":"10px","width":"1px"}},"borderColor":"border-color","layout":{"type":"default"}} -->
	<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:woocommerce/product-image {"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->

	<!-- wp:post-terms {"term":"product_tag","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"capitalize"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"textColor":"body-text","fontSize":"small"} /-->

	<!-- wp:post-title {"textAlign":"center","level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0rem","top":"var:preset|spacing|20"}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"20px"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

	<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center","textColor":"secondary","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} /-->

	<!-- wp:woocommerce/product-button {"textAlign":"center","isDescendentOfQueryLoop":true,"className":"add-to-cart-sec","fontSize":"small"} /--></div>
	<!-- /wp:group -->
	<!-- /wp:woocommerce/product-template --></div>
	<!-- /wp:woocommerce/product-collection --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"22.67%","className":"product-box-2"} -->
	<div class="wp-block-column product-box-2" style="flex-basis:22.67%"><!-- wp:woocommerce/product-collection {"queryId":17,"query":{"perPage":1,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"post__in","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false,"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":2,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/hand-picked","hideControls":["inherit","hand-picked","filterable","order"],"queryContextIncludes":["collection"],"__privatePreviewState":{"isPreview":false,"previewMessage":"Actual products will vary depending on the page being viewed."}} -->
	<div class="wp-block-woocommerce-product-collection"><!-- wp:woocommerce/product-template -->
	<!-- wp:group {"className":"product-inner-box","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}},"border":{"radius":"10px","width":"1px"}},"borderColor":"border-color","layout":{"type":"default"}} -->
	<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:woocommerce/product-image {"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->

	<!-- wp:post-terms {"term":"product_tag","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"capitalize"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"textColor":"body-text","fontSize":"small"} /-->

	<!-- wp:post-title {"textAlign":"center","level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0rem","top":"var:preset|spacing|20"}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"20px"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

	<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center","textColor":"secondary","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} /-->

	<!-- wp:woocommerce/product-button {"textAlign":"center","isDescendentOfQueryLoop":true,"className":"add-to-cart-sec","fontSize":"small"} /--></div>
	<!-- /wp:group -->
	<!-- /wp:woocommerce/product-template --></div>
	<!-- /wp:woocommerce/product-collection --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"22.67%","className":"product-box-3"} -->
	<div class="wp-block-column product-box-3" style="flex-basis:22.67%"><!-- wp:woocommerce/product-collection {"queryId":19,"query":{"perPage":1,"pages":0,"offset":0,"postType":"product","order":"asc","orderBy":"post__in","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[],"filterable":false,"relatedBy":{"categories":true,"tags":true}},"tagName":"div","displayLayout":{"type":"flex","columns":2,"shrinkColumns":true},"dimensions":{"widthType":"fill"},"collection":"woocommerce/product-collection/hand-picked","hideControls":["inherit","hand-picked","filterable","order"],"queryContextIncludes":["collection"],"__privatePreviewState":{"isPreview":false,"previewMessage":"Actual products will vary depending on the page being viewed."}} -->
	<div class="wp-block-woocommerce-product-collection"><!-- wp:woocommerce/product-template -->
	<!-- wp:group {"className":"product-inner-box","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}},"border":{"radius":"10px","width":"1px"}},"borderColor":"border-color","layout":{"type":"default"}} -->
	<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:woocommerce/product-image {"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->

	<!-- wp:post-terms {"term":"product_tag","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"typography":{"fontStyle":"normal","fontWeight":"400","textTransform":"capitalize"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}},"textColor":"body-text","fontSize":"small"} /-->

	<!-- wp:post-title {"textAlign":"center","level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0rem","top":"var:preset|spacing|20"}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"20px"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->

	<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"textAlign":"center","textColor":"secondary","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} /-->

	<!-- wp:woocommerce/product-button {"textAlign":"center","isDescendentOfQueryLoop":true,"className":"add-to-cart-sec","fontSize":"small"} /--></div>
	<!-- /wp:group -->
	<!-- /wp:woocommerce/product-template --></div>
	<!-- /wp:woocommerce/product-collection --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"32%","className":"product-box-4"} -->
	<div class="wp-block-column product-box-4" style="flex-basis:32%"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() . '/images/product4.png'); ?>","id":194,"dimRatio":0,"customOverlayColor":"#e5dbdf","isUserOverlayColor":false,"focalPoint":{"x":0.49,"y":0.4},"minHeight":380,"isDark":false,"sizeSlug":"full","style":{"border":{"radius":"10px"}},"layout":{"type":"default"}} -->
	<div class="wp-block-cover is-light" style="border-radius:10px;min-height:380px"><img class="wp-block-cover__image-background wp-image-194 size-full" alt="" src="<?php echo esc_url( get_template_directory_uri() . '/images/product4.png'); ?>" style="object-position:49% 40%" data-object-fit="cover" data-object-position="49% 40%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#e5dbdf"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"product-price-circle","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"secondary","layout":{"type":"default"}} -->
	<div class="wp-block-group product-price-circle has-secondary-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
	<h6 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color" style="font-size:16px;font-style:normal;font-weight:600"><?php esc_html_e('STARTING', 'electronics-market'); ?></h6>
	<!-- /wp:heading -->

	<!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"margin":{"top":"0","bottom":"0"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
	<h6 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:16px;font-style:normal;font-weight:600"><?php esc_html_e('AT $7999', 'electronics-market'); ?></h6>
	<!-- /wp:heading --></div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"product-text-box","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->
	<div class="wp-block-group product-text-box" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":6,"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|black"}}}},"textColor":"black"} -->
	<h6 class="wp-block-heading has-black-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:600"><a href="#"><?php esc_html_e('Headphone with Best Sound', 'electronics-market'); ?></a></h6>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"#707d95"}}},"typography":{"fontSize":"14px","textTransform":"capitalize"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"color":{"text":"#707d95"}}} -->
	<p class="has-text-color has-link-color" style="color:#707d95;margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:14px;text-transform:capitalize"><?php esc_html_e('and the fastest intel i7 sound ever', 'electronics-market'); ?></p>
	<!-- /wp:paragraph --></div>
	<!-- /wp:group --></div></div>
	<!-- /wp:cover --></div>
	<!-- /wp:column --></div>
	<!-- /wp:columns --></div>
	<!-- /wp:group -->
<?php } else { ?>
	<!-- wp:group {"className":"product-sec static-box","style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group product-sec static-box" style="padding-top:var(--wp--preset--spacing--80);padding-bottom:var(--wp--preset--spacing--80)"><!-- wp:group {"className":"sec-head-box","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group sec-head-box"><!-- wp:heading {"style":{"typography":{"fontSize":"35px","fontStyle":"normal","fontWeight":"600"}}} -->
<h2 class="wp-block-heading" style="font-size:35px;font-style:normal;font-weight:600"><?php esc_html_e('Smarts Phone &amp; Tablets', 'electronics-market'); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:buttons {"className":"section-btns","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-buttons section-btns"><!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Music', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Headphones', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Mobile', 'electronics-market'); ?></a></div>
	<!-- /wp:button -->

	<!-- wp:button {"backgroundColor":"background","textColor":"heading","style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50","top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"border":{"width":"1px"}},"fontFamily":"barlow-condensed","borderColor":"border-color"} -->
	<div class="wp-block-button"><a class="wp-block-button__link has-heading-color has-background-background-color has-text-color has-background has-link-color has-border-color has-border-color-border-color has-barlow-condensed-font-family wp-element-button" href="#" style="border-width:1px;padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--50)"><?php esc_html_e('Laptop', 'electronics-market'); ?></a></div>
	<!-- /wp:button --></div>
	<!-- /wp:buttons --></div>
	<!-- /wp:group -->

	<!-- wp:columns {"className":"product-sec-cols"} -->
	<div class="wp-block-columns product-sec-cols"><!-- wp:column {"width":"22.67%","className":"product-box-1"} -->
	<div class="wp-block-column product-box-1" style="flex-basis:22.67%"><!-- wp:group {"className":"product-inner-box","style":{"border":{"radius":"10px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}}},"borderColor":"border-color","layout":{"type":"default"}} -->
<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:image {"id":126,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/product1.png'); ?>" alt="" class="wp-image-126"/></figure>
	<!-- /wp:image -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Speakers', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<h3 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:20px;font-style:normal;font-weight:500"><a href="#"><?php esc_html_e('Yellow Speaker Waterproof with good sound', 'electronics-market'); ?></a></h3>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"0"}}},"textColor":"secondary"} -->
	<p class="has-text-align-center has-secondary-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:0;font-size:14px;font-style:normal;font-weight:700"><?php esc_html_e('$685,00', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"className":"product-cart-icon","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"default"}} -->
	<div class="wp-block-group product-cart-icon has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":175,"sizeSlug":"full","linkDestination":"none"} -->
	<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/cart.png'); ?>" alt="" class="wp-image-175"/></figure>
	<!-- /wp:image --></div>
	<!-- /wp:group --></div>
	<!-- /wp:group --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"22.67%","className":"product-box-2"} -->
	<div class="wp-block-column product-box-2" style="flex-basis:22.67%"><!-- wp:group {"className":"product-inner-box","style":{"border":{"radius":"10px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}}},"borderColor":"border-color","layout":{"type":"default"}} -->
<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:image {"id":137,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/product2.png'); ?>" alt="" class="wp-image-137"/></figure>
	<!-- /wp:image -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Camera', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<h3 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:20px;font-style:normal;font-weight:500"><a href="#"><?php esc_html_e('Camera C430W 4k Waterproof camera', 'electronics-market'); ?></a></h3>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"0"}}},"textColor":"secondary"} -->
	<p class="has-text-align-center has-secondary-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:0;font-size:14px;font-style:normal;font-weight:700"><?php esc_html_e('$685,00', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"className":"product-cart-icon","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"default"}} -->
	<div class="wp-block-group product-cart-icon has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":175,"sizeSlug":"full","linkDestination":"none"} -->
	<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/cart.png'); ?>" alt="" class="wp-image-175"/></figure>
	<!-- /wp:image --></div>
	<!-- /wp:group --></div>
	<!-- /wp:group --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"22.67%","className":"product-box-3"} -->
	<div class="wp-block-column product-box-3" style="flex-basis:22.67%"><!-- wp:group {"className":"product-inner-box","style":{"border":{"radius":"10px","width":"1px"},"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|70","right":"var:preset|spacing|70"}}},"borderColor":"border-color","layout":{"type":"default"}} -->
<div class="wp-block-group product-inner-box has-border-color has-border-color-border-color" style="border-width:1px;border-radius:10px;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)"><!-- wp:image {"id":125,"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/product3.png'); ?>" alt="" class="wp-image-125"/></figure>
	<!-- /wp:image -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"16px"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<p class="has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:16px"><?php esc_html_e('Mobile', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}}}} -->
	<h3 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:20px;font-style:normal;font-weight:500"><a href="#"><?php esc_html_e('Smartphone 6S 32GB LTE pro', 'electronics-market'); ?></a></h3>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"14px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|secondary"}}},"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"0"}}},"textColor":"secondary"} -->
	<p class="has-text-align-center has-secondary-color has-text-color has-link-color" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:0;font-size:14px;font-style:normal;font-weight:700"><?php esc_html_e('$685,00', 'electronics-market'); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"className":"product-cart-icon","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"primary","layout":{"type":"default"}} -->
	<div class="wp-block-group product-cart-icon has-primary-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":175,"sizeSlug":"full","linkDestination":"none"} -->
	<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/cart.png'); ?>" alt="" class="wp-image-175"/></figure>
	<!-- /wp:image --></div>
	<!-- /wp:group --></div>
	<!-- /wp:group --></div>
	<!-- /wp:column -->

	<!-- wp:column {"width":"35%","className":"product-box-4"} -->
	<div class="wp-block-column product-box-4" style="flex-basis:35%"><!-- wp:cover {"url":"<?php echo esc_url( get_template_directory_uri() . '/images/product4.png'); ?>","id":194,"dimRatio":0,"customOverlayColor":"#e5dbdf","isUserOverlayColor":false,"focalPoint":{"x":0.49,"y":0.4},"minHeight":380,"isDark":false,"sizeSlug":"full","style":{"border":{"radius":"10px"}},"layout":{"type":"default"}} -->
	<div class="wp-block-cover is-light" style="border-radius:10px;min-height:380px"><img class="wp-block-cover__image-background wp-image-194 size-full" alt="" src="<?php echo esc_url( get_template_directory_uri() . '/images/product4.png'); ?>" style="object-position:49% 40%" data-object-fit="cover" data-object-position="49% 40%"/><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim" style="background-color:#e5dbdf"></span><div class="wp-block-cover__inner-container"><!-- wp:group {"className":"product-price-circle","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"secondary","layout":{"type":"default"}} -->
	<div class="wp-block-group product-price-circle has-secondary-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
	<h6 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color" style="font-size:16px;font-style:normal;font-weight:600"><?php esc_html_e('STARTING', 'electronics-market'); ?></h6>
	<!-- /wp:heading -->

	<!-- wp:heading {"textAlign":"center","level":6,"style":{"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"spacing":{"margin":{"top":"0","bottom":"0"}},"typography":{"fontSize":"16px","fontStyle":"normal","fontWeight":"600"}},"textColor":"white"} -->
	<h6 class="wp-block-heading has-text-align-center has-white-color has-text-color has-link-color" style="margin-top:0;margin-bottom:0;font-size:16px;font-style:normal;font-weight:600"><?php esc_html_e('AT $7999', 'electronics-market'); ?></h6>
	<!-- /wp:heading --></div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"product-text-box","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->
	<div class="wp-block-group product-text-box" style="margin-top:0;margin-bottom:0"><!-- wp:heading {"level":6,"style":{"typography":{"fontSize":"20px","fontStyle":"normal","fontWeight":"600"},"elements":{"link":{"color":{"text":"var:preset|color|black"}}}},"textColor":"black"} -->
	<h6 class="wp-block-heading has-black-color has-text-color has-link-color" style="font-size:20px;font-style:normal;font-weight:600"><a href="#"><?php esc_html_e('Headphone with Best Sound', 'electronics-market'); ?></a></h6>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"#707d95"}}},"typography":{"fontSize":"14px","textTransform":"capitalize"},"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"0"}},"color":{"text":"#707d95"}}} -->
	<p class="has-text-color has-link-color" style="color:#707d95;margin-top:var(--wp--preset--spacing--20);margin-bottom:0;font-size:14px;text-transform:capitalize"><?php esc_html_e('and the fastest intel i7 sound ever', 'electronics-market'); ?></p>
	<!-- /wp:paragraph --></div>
	<!-- /wp:group --></div></div>
	<!-- /wp:cover --></div>
	<!-- /wp:column --></div>
	<!-- /wp:columns --></div>
	<!-- /wp:group -->
<?php } ?>