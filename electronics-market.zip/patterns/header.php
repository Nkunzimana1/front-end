<?php
/**
 * Title: Header
 * Slug: electronics-market/header
 * Categories: electronics-market, header
 */
?>

<!-- wp:group {"className":"top-bar","layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group top-bar"><!-- wp:columns {"verticalAlignment":"center","className":"top-barmain","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"},"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"border":{"bottom":{"color":"var:preset|color|border-color","width":"1px"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center top-barmain" style="border-bottom-color:var(--wp--preset--color--border-color);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)"><!-- wp:column {"verticalAlignment":"center","className":"top-1"} -->
<div class="wp-block-column is-vertically-aligned-center top-1"><!-- wp:columns {"verticalAlignment":"center","className":"top-1-inner","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center top-1-inner"><!-- wp:column {"verticalAlignment":"center","className":"top-iner1"} -->
<div class="wp-block-column is-vertically-aligned-center top-iner1"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":46,"scale":"cover","sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/call.png'); ?>" alt="" class="wp-image-46" style="object-fit:cover"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px"}}} -->
<p style="font-size:14px"><?php esc_html_e('(00) 123 456 7890', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","className":"top-iner2"} -->
<div class="wp-block-column is-vertically-aligned-center top-iner2"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:image {"id":48,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/mail.png'); ?>" alt="" class="wp-image-48"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px"}}} -->
<p style="font-size:14px"><?php esc_html_e('support@example.com', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","className":"top-2"} -->
<div class="wp-block-column is-vertically-aligned-center top-2"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"14px","textTransform":"uppercase","letterSpacing":"2px"}}} -->
<p class="has-text-align-center" style="font-size:14px;letter-spacing:2px;text-transform:uppercase"><?php esc_html_e('Free Shipping on Orders $500+', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","className":"top-3"} -->
<div class="wp-block-column is-vertically-aligned-center top-3"><!-- wp:columns {"verticalAlignment":"center","className":"top-2-inner","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center top-2-inner"><!-- wp:column {"verticalAlignment":"center","className":"top-iner1"} -->
<div class="wp-block-column is-vertically-aligned-center top-iner1"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:image {"id":47,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/location.png'); ?>" alt="" class="wp-image-47"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px"}}} -->
<p style="font-size:14px"><?php esc_html_e('Store Location', 'electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","className":"top-iner2"} -->
<div class="wp-block-column is-vertically-aligned-center top-iner2"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:woocommerce/customer-account {"iconStyle":"line","iconClass":"wc-block-customer-account__account-icon","style":{"typography":{"fontSize":"14px"}}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"middle-header","layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group middle-header"><!-- wp:columns {"verticalAlignment":"center","className":"middle-hdrmain","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|20"},"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center middle-hdrmain" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:column {"verticalAlignment":"center","width":"30%","className":"logo-block"} -->
<div class="wp-block-column is-vertically-aligned-center logo-block" style="flex-basis:30%"><!-- wp:group {"className":"logo-row","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group logo-row"><!-- wp:site-logo /-->

<!-- wp:site-title {"style":{"elements":{"link":{"color":{"text":"var:preset|color|primary"}}},"typography":{"fontStyle":"normal","fontWeight":"700","fontSize":"28px"}},"textColor":"primary"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%","className":"search-block"} -->
<div class="wp-block-column is-vertically-aligned-center search-block" style="flex-basis:40%"><!-- wp:search {"label":"Search","showLabel":false,"placeholder":"Search for...","buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true,"query":{"post_type":"product"},"style":{"border":{"radius":"30px"},"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"backgroundColor":"ternary","textColor":"background","borderColor":"ternary","namespace":"woocommerce/product-search"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"30%","className":"translator-block"} -->
<div class="wp-block-column is-vertically-aligned-center translator-block" style="flex-basis:30%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:shortcode -->

<!-- /wp:shortcode --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"menu-header","style":{"spacing":{"padding":{"bottom":"0"}}},"layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group menu-header" style="padding-bottom:0"><!-- wp:columns {"className":"menu-hdrmain"} -->
<div class="wp-block-columns menu-hdrmain"><!-- wp:column {"verticalAlignment":"center","width":"25%","className":"head-cat-block"} -->
<div class="wp-block-column is-vertically-aligned-center head-cat-block" style="flex-basis:25%"><!-- wp:woocommerce/product-categories {"isDropdown":true,"className":"head-cat"} /--></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"60%","className":"nav-block"} -->
<div class="wp-block-column is-vertically-aligned-center nav-block" style="flex-basis:60%"><!-- wp:navigation {"textColor":"foreground","overlayBackgroundColor":"white","overlayTextColor":"black","metadata":{"ignoredHookedBlocks":["woocommerce/customer-account","woocommerce/mini-cart"]},"style":{"typography":{"textTransform":"uppercase","fontSize":"15px","fontStyle":"normal","fontWeight":"400"},"spacing":{"blockGap":"0"}},"layout":{"type":"flex","justifyContent":"space-between"}} -->
<!-- wp:navigation-link {"label":"Home","type":"","url":"#","kind":"custom","isTopLevelLink":true} /-->

<!-- wp:navigation-link {"label":"Catalog","type":"","url":"#","kind":"custom","isTopLevelLink":true,"className":"menu-new"} /-->

<!-- wp:navigation-submenu {"label":"Gift","type":"","url":"#","kind":"custom"} -->
	<!-- wp:navigation-link {"label":"Page 1","type":"","url":"#","kind":"custom","className":""} /-->

	<!-- wp:navigation-link {"label":"Page 2","type":"","url":"#","kind":"custom","className":""} /-->
<!-- /wp:navigation-submenu -->

<!-- wp:navigation-link {"label":"Pages","type":"","url":"#","kind":"custom","isTopLevelLink":true,"className":"menu-sale"} /-->

<!-- wp:navigation-link {"label":"Features","type":"","url":"#","kind":"custom","isTopLevelLink":true,"className":"menu-hot"} /-->
<!-- /wp:navigation --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"15%","className":"cart-box"} -->
<div class="wp-block-column is-vertically-aligned-center cart-box" style="flex-basis:15%"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group"><!-- wp:image {"lightbox":{"enabled":false},"id":128,"sizeSlug":"full","linkDestination":"custom"} -->
<figure class="wp-block-image size-full"><a href="#"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/wishlist.png'); ?>" alt="" class="wp-image-128"/></a></figure>
<!-- /wp:image -->

<!-- wp:woocommerce/mini-cart {"miniCartIcon":"bag-alt","iconColor":{"color":"#000000","name":"Headings","slug":"heading","class":"has-heading-icon-color"},"productCountColor":{"color":"#FFC200","name":"Ternary","slug":"ternary","class":"has-ternary-product-count-color"}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->