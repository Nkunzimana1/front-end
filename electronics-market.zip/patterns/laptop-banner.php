<?php
/**
 * Title: Laptop Banner
 * Slug: electronics-market/laptop-banner
 * Categories: electronics-market, laptop-banner
 */
?>

<!-- wp:group {"className":"laptop-baner","style":{"spacing":{"padding":{"bottom":"0","top":"var:preset|spacing|50","right":"0","left":"0"}}},"gradient":"diagonal-ternary-to-ternary-light","layout":{"type":"constrained","contentSize":"85%"}} -->
<div class="wp-block-group laptop-baner has-diagonal-ternary-to-ternary-light-gradient-background has-background" style="padding-top:var(--wp--preset--spacing--50);padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:group {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-bottom:var(--wp--preset--spacing--50)"><!-- wp:heading {"className":"laptop-bnr-main-heading","style":{"typography":{"fontSize":"65px","fontStyle":"normal","fontWeight":"700"}}} -->
<h2 class="wp-block-heading laptop-bnr-main-heading" style="font-size:65px;font-style:normal;font-weight:700"><?php esc_html_e('G9 Laptop With Ultra 4k','electronics-market'); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|heading"}}},"typography":{"fontSize":"20px"}},"textColor":"heading"} -->
<p class="has-heading-color has-text-color has-link-color" style="font-size:20px"><?php esc_html_e('And The Fastest Intel Core I7 Processor Ever','electronics-market'); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"id":10,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="<?php echo esc_url( get_template_directory_uri() . '/images/laptop-img.png'); ?>" alt="" class="wp-image-10"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->