<?php
// Connect to the database
$con = mysqli_connect("localhost", "root", "", "coffeeShop");

// Check connection
if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

// Fetch all customers
$result = mysqli_query($con, "SELECT * FROM customers");

// Display table
echo "<h2>Registered Users (Admins and Customers)</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr>
        
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Role</th>
      </tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    // echo "<td>" . htmlspecialchars($row['id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
    echo "<td>" . htmlspecialchars($row['password']) . "</td>";
    echo "<td>" . htmlspecialchars($row['role']) . "</td>";
    echo "</tr>";
}

echo "</table>";

mysqli_close($con);
?>
