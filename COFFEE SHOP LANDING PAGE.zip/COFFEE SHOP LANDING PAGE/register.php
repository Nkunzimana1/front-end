<?php
// register.php

// Connect to database
$con = mysqli_connect("localhost", "root", "", "coffeeShop");
if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

// Get POST data and sanitize
$name = trim($_POST['name']);
$email = trim($_POST['email']);
$password = $_POST['password']; // you should hash this before storing!
$role = $_POST['role'];

// Check if email already exists
$query = "SELECT * FROM customers WHERE email = ?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    // Email exists, show error (you can customize this)
    echo "<script>alert('Email already exists. Please use another email.'); window.history.back();</script>";
    exit();
}

// Validate inputs here if not done client-side

// Hash password before saving (recommended)
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$insertQuery = "INSERT INTO customers (name, email, password, role) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($con, $insertQuery);
mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $password, $role);
if (mysqli_stmt_execute($stmt)) {
    // Registration successful
    echo "<script>alert('Registration successful! Please login.'); window.location.href='login.html';</script>";
} else {
    echo "Error: " . mysqli_error($con);
}

mysqli_close($con);
?>
