<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=users.csv');

// Connect to the database
$con = mysqli_connect("localhost", "root", "", "coffeeShop");
if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

// Output CSV headers
$output = fopen('php://output', 'w');
fputcsv($output, ['Name', 'Email', 'Password', 'Role']);

// Fetch data
$result = mysqli_query($con, "SELECT name, email, password, role FROM customers");
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, $row);
}

fclose($output);
mysqli_close($con);
?>
