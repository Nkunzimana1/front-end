<?php 
// Connect to the database
$con = mysqli_connect("localhost", "root", "", "coffeeShop");

// Check connection
if (mysqli_connect_errno()) {
    echo "<script>alert('Failed to connect to MySQL: " . mysqli_connect_error() . "');</script>";
    exit();
}

// Get and sanitize input
$email = mysqli_real_escape_string($con, $_POST['email']);
$password = mysqli_real_escape_string($con, $_POST['password']);

// Query to check credentials
$query = "SELECT * FROM customers WHERE email='$email' AND password='$password'";
$result = mysqli_query($con, $query);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $role = strtolower(trim($row['role'])); // normalize and trim

    if ($role == 'customer') {
        echo "<script>
            alert('Login successful!');
            window.location.href = 'index.html#menu';
        </script>";
    } elseif ($role == 'admin') {
        echo "<script>
            alert('Login successful!');
            window.location.href = 'admin.html';
        </script>";
    } else {
        echo "<script>
            alert('Unknown role: $role. Please contact support.');
            window.location.href = 'login.html';
        </script>";
    }
} else {
    echo "<script>
        alert('Invalid email or password!');
        window.location.href = 'login.html';
    </script>";
}

mysqli_close($con);
?>
